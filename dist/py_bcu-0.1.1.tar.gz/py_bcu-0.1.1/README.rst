PyPi: https://pypi.org/project/py-bcu/

pip install py-bcu

Inspirado en: https://github.com/biller/bcu

https://blog.jetbrains.com/pycharm/2017/05/how-to-publish-your-package-on-pypi/